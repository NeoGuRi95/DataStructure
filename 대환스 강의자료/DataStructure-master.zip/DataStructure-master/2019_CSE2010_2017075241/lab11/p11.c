#include <stdio.h>
#include <stdlib.h>
#include <string.h>
 
#define Inf 99999
 
typedef struct Node {
   int key;
   int weight;
}Node;
typedef struct Heap {
   int capacity;
   int size;
   Node* element;
}Heap;
 
Heap* createMinHeap(int heapSize); //MinHeap생성
void insert(Heap* minHeap, int vertex, int distance); //MinHeap에 Node삽입
int deleteMin(Heap* minHeap); //MinHeap에서 최솟값이 들어있는 Node삭제
void printShortestPath(int* pred, int end, FILE *fout); //목적지까지의 최단 루트 출력
void dijkstra(int* d, int* pred, int** w,int heapSize, int start); //dijkstra 알고리즘을 이용하여 시작vertex부터 vertex별 최단 거리 계산
void decrease(Heap* minHeap, int vertex, int distance); //MinHeap에 들어있는 특정 vertex의 distance값 수정후 BuildHeap
void buildHeap(Node* element, int heapSize); //MinHeap으로 정렬
void heapify(Node* element, int k, int n); //MinHeap으로 정렬
 
int main()
{
   int vertex;
   int heapSize = 0;
   int *d;
   d = (int*)malloc(sizeof(int));
   int *pred;
   int **w;
   int row, col, weight;
   int start, end;
   FILE *fin,*fout;
   fin = fopen("input.txt", "r");
   fout = fopen("output.txt", "w");
   char line[100];
   fgets(line, sizeof(line), fin);
   char *ptr = strtok(line, " ");
   while (ptr != NULL)
   {
      sscanf(ptr, "%d", &vertex);
      d = (int*)realloc(d, sizeof(int)*(++heapSize + 1));
      d[vertex] = Inf;
      ptr = strtok(NULL, " ");
   }
   pred = (int*)malloc(sizeof(int)*(heapSize + 1));
   w = (int**)malloc(sizeof(int*)*(heapSize + 1));
   for (int i = 0; i < heapSize + 1; i++)
   {
      w[i] = (int*)malloc(sizeof(int)*(heapSize + 1));
   }
   for (int i = 1; i < heapSize + 1; i++)
   {
      for (int j = 1; j < heapSize + 1; j++)
      {
         w[i][j] = Inf;
      }
   }
   fgets(line, sizeof(line), fin);
   char *ptr2 = strtok(line, "-");
   while (ptr2 != NULL)
   {
      sscanf(ptr2, "%d", &row);
      ptr2 = strtok(NULL, "-");
      sscanf(ptr2, "%d", &col);
      ptr2 = strtok(NULL, " ");
      sscanf(ptr2, "%d", &weight);
      w[row][col] = weight;
      ptr2 = strtok(NULL, "-");
   }
   fgets(line, sizeof(line), fin);
   char *ptr3 = strtok(line, " ");
   sscanf(ptr3, "%d", &start);
   ptr3 = strtok(NULL, " ");
   sscanf(ptr3, "%d", &end);
   dijkstra(d, pred, w, heapSize, start);
   printShortestPath(pred, end, fout);
   free(d);
   free(pred);
   for (int i = 0; i <= heapSize; i++) {
	   free(w[i]);
   }
   free(w);
   fclose(fin);
   fclose(fout);

   return 0;
}
 
Heap* createMinHeap(int heapSize)
{
   Heap *minHeap;
   minHeap = malloc(sizeof(Heap));
   minHeap->capacity = heapSize;
   minHeap->size = 0;
   minHeap->element = malloc(sizeof(Node)*(minHeap->capacity + 1));
 
   return minHeap;
}
void insert(Heap* minHeap, int vertex, int distance)
{
   int i;
   if (minHeap->capacity == minHeap->size)
   {
      printf("Priority queue is full\n");
      return;
   }
   for (i = ++minHeap->size; minHeap->element[i / 2].weight > distance; i /= 2)
      minHeap->element[i] = minHeap->element[i / 2];
   minHeap->element[i].key = vertex;
   minHeap->element[i].weight = distance;
}
int deleteMin(Heap* minHeap)
{
   int i, Child;
   Node MinElement, LastElement;
   MinElement = minHeap->element[1];
   LastElement = minHeap->element[minHeap->size--];
   for (i = 1; i * 2 <= minHeap->size; i = Child)
   {
      Child = i * 2;
      if (Child != minHeap->size && minHeap->element[Child + 1].weight < minHeap->element[Child].weight)
         Child++;
      if (LastElement.weight > minHeap->element[Child].weight)
         minHeap->element[i] = minHeap->element[Child];
      else
         break;
   }
   minHeap->element[i] = LastElement;
   return MinElement.key;
}
void printShortestPath(int* pred, int end, FILE *fout)
{
	if (pred[end] == Inf)
	{
		fprintf(fout,"No path.\n");
		return;
	}
	else if (pred[end] > 0)
	{
		printShortestPath(pred, pred[end], fout);
		fprintf(fout, "%d ", end);
	}
	else
		fprintf(fout, "%d ",end);
}
void dijkstra(int* d, int* pred, int** w, int heapSize, int start)
{
	for (int i = 1; i <= heapSize; i++)
	{
		if (i == start){
			d[i] = 0;
			pred[i]=0;
		}
		else {
			d[i] = Inf;
			pred[i] = Inf;
		}
	}
	for (int i = 1; i <= heapSize; i++)
	{
		if (w[start][i] != Inf)
		{
			d[i] = w[start][i];
			pred[i] = start;
		}
	}
	Heap* minHeap = createMinHeap(heapSize);
	for (int vertex = 1; vertex <= heapSize; vertex++)
	{
		if (vertex == start)
			insert(minHeap, vertex, 0);
		else
			insert(minHeap, vertex, Inf);
	}
	while (minHeap->size != 0)
	{
		int u = deleteMin(minHeap);
		for (int v = 1; v <= heapSize; v++)
		{
			if (w[u][v] != Inf)
			{
				if (d[u] + w[u][v] < d[v])
				{
					d[v] = d[u] + w[u][v];
					pred[v] = u;
					decrease(minHeap, v, d[v]);
				}
			}
		}
	}
	free(minHeap->element);
	free(minHeap);
}
void decrease(Heap* minHeap, int vertex, int distance)
{
	for (int i = 1; i <= minHeap->capacity; i++)
	{
		if (minHeap->element[i].key == vertex)
		{
			minHeap->element[i].weight = distance;
			buildHeap(minHeap->element, minHeap->capacity);
			break;
		}
	}
}
void buildHeap(Node* element, int heapSize)
{
	for (int i = heapSize / 2; i > 0; i--)
	{
		heapify(element, i, heapSize);
	}
}
void heapify(Node* element, int k, int n)
{
	int left, right;
	int MIN;
	left = 2 * k;
	right = (2 * k) + 1;
	if (right <= n)
	{
		if (element[left].weight < element[right].weight)
		{
			MIN = left;
		}
		else
		{
			MIN = right;
		}
	}
	else if (left <= n)
	{
		MIN = left;
	}
	else {
		return;
	}
	if (element[MIN].weight < element[k].weight)
	{
		int tempkey = element[MIN].key;
		int tempweight = element[MIN].weight;
		element[MIN].key = element[k].key;
		element[MIN].weight = element[k].weight;
		element[k].key = tempkey;
		element[k].weight = tempweight;
		heapify(element, MIN, n);
	}
}

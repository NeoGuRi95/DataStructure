#include <stdio.h>

#include <stdlib.h>

 

typedef struct threaded_tree *threaded_ptr;

typedef struct threaded_tree {

	short int left_thread;

	threaded_ptr left_child;

	char data;

	threaded_ptr right_child;

	short int right_thread;

}threaded_tree;

typedef struct _Node{

	struct _Node *next;

	struct _Node *prev;

	threaded_ptr tree;

}Node;

typedef struct _queue {

	Node *front;

	Node *rear;

}Queue;

 

void InitQue(Queue *queue); //큐 초기화.

void InitRoot(threaded_tree *Root); //트리의 Root 초기화.

void InsertNode(char data, Queue *queue,threaded_tree *Root); //data를 큐를 이용하여 complete binary방식으로 Root노드에 연결. 

void Enqueue(Queue *queue, threaded_ptr tree_node); //tree노드를 큐의 맨 끝부분에 연결.

void Dequeue(Queue *queue); //큐의 맨 앞 노드 삭제.

threaded_ptr insucc(threaded_ptr tree); //inorder 후속 노드를 찾아 return.

void tinorder(Queue *queue,threaded_ptr tree_node, FILE *fout); //inorder 방식으로 txt파일에 출력.

void thread(Queue *queue,threaded_tree *Root); //leaf노드를 찾아 threaded binary tree 형식으로 연결.

void inorder(Queue *queue,threaded_ptr tree_node); //tree를 inorder방식으로 큐에 연결.

void MakeQueueEmpty(Queue *queue); //큐의 모든 노드 삭제.

void MakeTreeEmpty(threaded_ptr tree_node); //트리의 모든 노드 삭제.

int main()

{

	int n;

	char data;

	FILE *fin,*fout;

	fin = fopen("input.txt", "r");

	fout = fopen("output.txt", "w");

	threaded_tree Root;

	InitRoot(&Root);

	Queue queue;

	InitQue(&queue);

	Queue insuccqueue;

	InitQue(&insuccqueue);

	fscanf(fin, "%d ",&n);

	for(int i = 0; i < n; i++)

	{

		fscanf(fin, "%c ", &data);

		InsertNode(data, &queue ,&Root);

	}

	MakeQueueEmpty(&queue);

	inorder(&queue, Root.left_child);

	thread(&queue, &Root);

	tinorder(&queue, &Root, fout);

	MakeQueueEmpty(&queue);

	MakeTreeEmpty(Root.left_child);

	fclose(fin);

	fclose(fout);

 

	return 0;

}

void InitQue(Queue *queue)

{

	queue->front = NULL;

	queue->rear = NULL;

}

 

void InitRoot(threaded_tree *Root)

{

	Root->left_child = NULL;

	Root->left_thread = 1;

	Root->right_child = Root;

	Root->right_thread = 0;

}

 

void InsertNode(char data, Queue *queue, threaded_tree *Root)

{

	threaded_ptr tree_node = (threaded_tree*)malloc(sizeof(threaded_tree));

	tree_node->data = data;

	tree_node->left_child = NULL;

	tree_node->right_child = NULL;

	tree_node->left_thread = 1;

	tree_node->right_thread = 1;

	if (queue->front == NULL)

	{

		Enqueue(queue, tree_node);

		Root->left_thread = 0;

		Root->left_child = tree_node;

	}

	else

	{

		if (queue->front->tree->left_child == NULL)

		{

			queue->front->tree->left_child = tree_node;

			queue->front->tree->left_thread = 0;

		}

		else if (queue->front->tree->left_child != NULL)

		{

			queue->front->tree->right_child = tree_node;

			queue->front->tree->right_thread = 0;

			Dequeue(queue);

		}

		Enqueue(queue, tree_node);

	}

}

 

void Enqueue(Queue *queue, threaded_ptr tree_node)

{

	Node *newNode = (Node*)malloc(sizeof(Node));

	newNode->tree = tree_node;

	newNode->prev = NULL;

	newNode->next = NULL;

	if (queue->front == NULL)

	{

		queue->front = newNode;

		queue->rear = newNode;

	}

	else

	{	

		queue->rear->next = newNode;

		newNode->prev = queue->rear;

		queue->rear = newNode;

	}

}

 

void Dequeue(Queue *queue)

{

	if (queue->front == NULL)

		return;

	else if (queue->front->next == NULL) {

		queue->front = NULL;

		free(queue->front);

	}

	else

	{

		Node *delNode;

		delNode = queue->front;

		queue->front = delNode->next;

		queue->front->prev = NULL;

		free(delNode);

	}

}

threaded_ptr insucc(threaded_ptr tree_node) {

	threaded_ptr temp;

	temp = tree_node->right_child;

	if (!tree_node->right_thread)

		while (!temp->left_thread)

			temp = temp->left_child;

	return temp;

}

void tinorder(Queue *queue,threaded_ptr tree_node,FILE *fout) {

	threaded_ptr temp = tree_node;

	for (;;) {

		temp = insucc(temp);

		if (temp == tree_node) break;

		fprintf(fout,"%c ", temp->data);

	}

}

void thread(Queue *queue, threaded_tree *Root) {

	Node *temp;

	temp = queue->front;

	while (temp != NULL)

	{

		if (temp->tree->left_thread) {

			if (temp->prev == NULL)

				temp->tree->left_child = Root;

			else

				temp->tree->left_child = temp->prev->tree;

		}

		if (temp->tree->right_thread) {

			if (temp->next == NULL)

				temp->tree->right_child = Root;

			else

				temp->tree->right_child = temp->next->tree;

		}

		temp = temp->next;

	}

}

void inorder(Queue *queue,threaded_ptr tree_node) {

	if (tree_node) {

		inorder(queue,tree_node->left_child);

		Enqueue(queue,tree_node);

		inorder(queue,tree_node->right_child);

	}

}

void MakeQueueEmpty(Queue *queue) {

	while (queue->front != NULL)

		Dequeue(queue);

}

void MakeTreeEmpty(threaded_ptr tree_node) {

	if (tree_node->left_thread)

	{

		free(tree_node);

		return;

	}

	MakeTreeEmpty(tree_node->left_child);

	MakeTreeEmpty(tree_node->right_child);

	free(tree_node);

}


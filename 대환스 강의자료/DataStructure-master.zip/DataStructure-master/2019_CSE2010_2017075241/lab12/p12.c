#include <stdio.h>
#include <stdlib.h>
#include <string.h>
 
typedef struct ListNode *Position;
typedef Position List;
typedef struct HashTbl *HashTable;
typedef struct HashTbl {
	int currentSize;
	int TableSize;
	int* TheLists;
}HashTbl;
 
void Insert(HashTable H, int value, int solution, FILE* fout); // hash table에 value삽입.
void delete(HashTable H, int value, int solution, FILE* fout); // hash table에 value삭제.
int find(HashTable H, int value, int solution); // hash table에 value가 있으면 해당 index반환, 없으면 -1반환.
void print(HashTable H, FILE* fout); // hash table의 모든 value 출력.
int Hash(int value, int Size, int i, int solution); //  hash table에 들어갈 index 계산.
 
int main()
{
	int caseNum;
	int solution;
	int tableSize;
	int value;
	FILE *fin,*fout;
	fin = fopen("input.txt", "r");
	fout = fopen("output.txt", "w");
	fscanf(fin, "%d ", &caseNum);
	while (!feof(fin))
	{
		char colSolution[20];
		char code = '\0';
		fgets(colSolution, sizeof(colSolution), fin);
		fprintf(fout, "%s", colSolution);
		colSolution[strlen(colSolution)-2] = '\0';
		if (strcmp(colSolution, "Linear") == 0)
		{
			solution = 1;
		}
		else if (strcmp(colSolution, "Quadratic") == 0)
		{
			solution = 2;
		}
		else if (strcmp(colSolution, "Double") == 0)
		{
			solution = 3;
		}
		fscanf(fin,"%d ", &tableSize);
		HashTable H = (HashTbl*)malloc(sizeof(HashTbl));
		H->currentSize = 0;
		H->TableSize = tableSize;
		H->TheLists = (int*)malloc(sizeof(int)*H->TableSize);
		for (int i = 0; i < H->TableSize; i++)
			H->TheLists[i] = 0;
		while (code != 'q')
		{
			fscanf(fin, "%c ", &code);
			switch (code)
			{
			case 'i':
				fscanf(fin, "%d ", &value);
				Insert(H, value, solution, fout);
				break;
			case 'f':
				fscanf(fin, "%d ", &value);
				if (find(H, value, 1) == -1)
					fprintf(fout, "Not found\n");
				else
					fprintf(fout, "%d\n", find(H, value, 1));
				break;
			case 'd':
				fscanf(fin, "%d ", &value);
				delete(H, value, solution, fout);
				break;
			case 'p':
				print(H,fout);
				break;
			case 'q':
				free(H->TheLists);
				free(H);
				break;
			}
		}
	}
	fclose(fin);
	fclose(fout);
 
	return 0;
}
void Insert(HashTable H, int value, int solution, FILE* fout)
{
	if (value <= 0) {
		fprintf(fout, "Value is always positive integer.\n");
		return;
	}
	if (H->currentSize == H->TableSize)
	{
		fprintf(fout, "Full\n");
		return;
	}
	if (find(H, value, 1) == -1)
	{
		int i = 0;
		int index = Hash(value, H->TableSize, i, solution);
		while (H->TheLists[index] != 0)
		{
			i++;
			index = Hash(value, H->TableSize, i, solution);
		}
		H->TheLists[index] = value;
		H->currentSize++;
		fprintf(fout,"Inserted %d\n", value);
	}
	else
	{
		fprintf(fout,"Already exists\n");
	}
}
void delete(HashTable H, int value, int solution, FILE* fout)
{
	if (find(H, value, 1) == -1)
	{
		fprintf(fout,"%d not exists\n", value);
	}
	else
	{
		fprintf(fout,"Deleted %d\n", value);
		H->TheLists[find(H, value, solution)] = 0;
	}
}
int find(HashTable H, int value, int solution)
{
	int i = 0;
	int index = Hash(value, H->TableSize, i, solution);
	while (H->TheLists[index] != value)
	{
		i++;
		if (i == H->TableSize)
			return -1;
		index = Hash(value, H->TableSize, i, solution);
	}
	return index;
}
void print(HashTable H, FILE* fout)
{
	if (H->currentSize == 0) {
		fprintf(fout,"0\n");
		return;
	}
	for (int i = 0; i < H->TableSize; i++)
		fprintf(fout,"%d ", H->TheLists[i]);
	fprintf(fout, "\n\n");
}
int Hash(int value, int Size, int i, int solution)
{
	if (solution == 1)
		return (value % Size + i) % Size;
	else if (solution == 2)
		return (value % Size + i * i) % Size;
	else if (solution == 3)
		return (value % Size + i * (7 - (value % 7))) % Size;
}

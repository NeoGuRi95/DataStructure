#include <stdio.h>
#include <stdlib.h>
#include <string.h>
 
typedef struct TreeNode *treeptr;
typedef struct TreeNode {
	int value;
	treeptr *left, *right;
}TreeNode;

TreeNode* InsertNode(int value, TreeNode *root, FILE *fout); //트리에 새 노드를 추가하는 함수.
TreeNode* DeleteNode(int value, TreeNode *root, FILE *fout); //트리의 노드를 삭제하는 함수.
TreeNode* FindNode(int value, TreeNode *root, FILE *fout); //특정 value가 트리에 있는지 확인하고 있으면 해당 노드를 반환하는 함수.
TreeNode* FindMax(TreeNode *root); //트리에서 가장 큰 value를 갖고 있는 노드를 찾아 반환하는 함수.
void PrintInorder(TreeNode *root, FILE *fout); //inorder 방식으로 트리의 value값을 출력하는 함수.
void PrintPreorder(TreeNode *root, FILE *fout); //preorder 방식으로 트리의 value값을 출력하는 함수.
void PrintPostorder(TreeNode *root, FILE *fout); //postorder 방식으로 트리의 value값을 출력하는 함수.
void MakeTreeEmpty(TreeNode *root); //모든 트리노드의 할당된 메모리를 free함수를 통해 삭제하는 함수.

int main()
{
	char code[3];
	int value;
	FILE *fin,*fout;
	fin = fopen("input.txt", "r");
	fout = fopen("output.txt", "w");
	TreeNode *root = NULL;
	while (!feof(fin)) {
		fscanf(fin, "%s ", code);
		if (strcmp(code, "i") == 0) {
			fscanf(fin,"%d ", &value);
			root = InsertNode(value, root, fout);
		}
		else if (strcmp(code, "d") == 0) {
			fscanf(fin,"%d ", &value);
			DeleteNode(value, root, fout);
		}
		else if (strcmp(code, "f") == 0) {
			fscanf(fin,"%d ", &value);
			FindNode(value, root, fout);
		}
		else if (strcmp(code, "pi") == 0) {
			fprintf(fout,"pi - ");
			PrintInorder(root, fout);
			fprintf(fout,"\n");
		}
		else if (strcmp(code, "pr") == 0) {
			fprintf(fout,"pr - ");
			PrintPreorder(root, fout);
			fprintf(fout,"\n");
		}
		else if (strcmp(code, "po") == 0) {
			fprintf(fout,"po - ");
			PrintPostorder(root, fout);
			fprintf(fout,"\n");
		}
	}
	MakeTreeEmpty(root);
	fclose(fin);
	fclose(fout);
	return 0;
}
 
TreeNode* InsertNode(int value, TreeNode *root,FILE *fout) {
	if (root == NULL) {
		root = malloc(sizeof(struct TreeNode));
		if (root == NULL)
			fprintf(fout,"Out of space!!!\n");
		else
		{
			root->value = value;
			root->left = root->right = NULL;
		}
	}
	else if (value < root->value) {
		root->left = InsertNode(value, root->left, fout);
	}
	else if (value > root->value)
		root->right = InsertNode(value, root->right, fout);
	else
		fprintf(fout,"%d already exists.\n", value);
 
	return root;
}
 
TreeNode* DeleteNode(int value, TreeNode *root, FILE *fout) {
	TreeNode *TmpCell;
	if (root == NULL)
		fprintf(fout,"Deletion failed. %d does not exist.\n",value);
	else if (value < root->value) 
		root->left = DeleteNode(value, root->left, fout);
	else if (value > root->value)
		root->right = DeleteNode(value, root->right, fout);
	else if (root->left && root->right) {
		TmpCell = FindMax(root->left);
		root->value = TmpCell->value;
		root->left = DeleteNode(root->value, root->left, fout);
	}
	else {
		TmpCell = root;
		if (root->left == NULL)
			root = root->right;
		else if (root->right == NULL)
			root = root->left;
		free(TmpCell);
	}
	return root;
}
TreeNode* FindNode(int value, TreeNode *root, FILE *fout) {
	if (root == NULL) {
		fprintf(fout,"%d is not in the tree.\n", value);
		return NULL;
	}
	if (value < root->value)
		return FindNode(value, root->left, fout);
	else if (value > root->value)
		return FindNode(value, root->right, fout);
	else {
		fprintf(fout,"%d is in the tree.\n", value);
		return root;
	}
}
TreeNode* FindMax(TreeNode *root) {
	if (root == NULL)
		return NULL;
	else {
		while (root->right != NULL)
			root = root->right;
		return root;
	}
}
void PrintInorder(TreeNode *root, FILE *fout) {
	if (root) {
		PrintInorder(root->left, fout);
		fprintf(fout,"%d ", root->value);
		PrintInorder(root->right, fout);
	}
}
void PrintPreorder(TreeNode *root, FILE *fout) {
	if (root) {
		fprintf(fout,"%d ", root->value);
		PrintPreorder(root->left, fout);
		PrintPreorder(root->right, fout);
	}
}
void PrintPostorder(TreeNode *root, FILE *fout) {
	if (root) {
		PrintPostorder(root->left, fout);
		PrintPostorder(root->right, fout);
		fprintf(fout,"%d ", root->value);
	}
}
void MakeTreeEmpty(TreeNode *root) {
	if (root) {
		MakeTreeEmpty(root->left);
		MakeTreeEmpty(root->right);
		free(root);
	}
}

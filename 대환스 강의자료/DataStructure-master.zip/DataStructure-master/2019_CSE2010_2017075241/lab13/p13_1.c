#include <stdio.h>
#include <stdlib.h>
#include <string.h>
 
void Print(int *A, int *TmpArray, int NumOfInput); //Input Array와 Merge 실행후 Array 출력
void IMsort(int *A, int *TmpArray, int Left, int Right); //iterative하게 정의된 MergeSort함수
void RMsort(int *A, int *TmpArray, int Left, int Right); //recursive하게 정의된 MergeSort함수
void Merge(int *A, int *TmpArray, int Lpos, int Rpos, int RightEnd); //값이 작은순으로 Merge하는 함수

int main()
{
	FILE *fin;
	fin = fopen("input.txt", "r");
	int *A, *TmpArray, NumOfInput, Input;
	fscanf(fin, "%d ", &NumOfInput);
	A = (int*)malloc(sizeof(int)*NumOfInput);
	TmpArray = (int*)malloc(sizeof(int)*NumOfInput);
	for (int i = 0; i < NumOfInput; i++) {
		fscanf(fin, "%d ", &Input);
		A[i] = Input;
	}
	Print(A, TmpArray, NumOfInput);
	free(A);
	free(TmpArray);
	fclose(fin);
	return 0;
}
void Print(int *A, int *TmpArray, int NumOfInput) {
	int *B = (int*)malloc(sizeof(int)*NumOfInput);
	for (int i = 0; i < NumOfInput; i++)
		B[i] = A[i];
	printf("Input :\n");
	for (int i = 0; i < NumOfInput; i++)
		printf("%d ", A[i]);
	printf("\n\niterative :\n");
	IMsort(A, TmpArray, 0, NumOfInput - 1);
	printf("\nrecursive :\n");
	RMsort(B, TmpArray, 0, NumOfInput - 1);
	free(B);
}
void IMsort(int *A, int *TmpArray, int Left, int Right) {
	int Center;
	for (int i = 2; i < Right; i *= 2) {
		for (Left = 0; Left < Right; Left += i) {
			Center = (2 * Left + i - 1) / 2;
			if (Right - Left < i) {
				Merge(A, TmpArray, Left, (Left+Right)/2 + 1, Right);
				break;
			}
			Merge(A, TmpArray, Left, Center + 1, Left + i - 1);
		}
	}
	Merge(A, TmpArray, 0, Left, Right);
}
void RMsort(int *A, int *TmpArray, int Left, int Right) {
	int Center;
	if (Left < Right) {
		Center = (Left + Right) / 2;
		RMsort(A, TmpArray, Left, Center);
		RMsort(A, TmpArray, Center + 1, Right);
		Merge(A, TmpArray, Left, Center + 1, Right);
	}
}
void Merge(int *A, int *TmpArray, int Lpos, int Rpos, int RightEnd) {
	int i, LeftEnd, NumElements, TmpPos;
	LeftEnd = Rpos - 1;
	TmpPos = Lpos;
	NumElements = RightEnd - Lpos + 1;
	while (Lpos <= LeftEnd && Rpos <= RightEnd)
		if (A[Lpos] <= A[Rpos])
			TmpArray[TmpPos++] = A[Lpos++];
		else
			TmpArray[TmpPos++] = A[Rpos++];
	while (Lpos <= LeftEnd)
		TmpArray[TmpPos++] = A[Lpos++];
	while (Rpos <= RightEnd)
		TmpArray[TmpPos++] = A[Rpos++];
	for (i = 0; i < NumElements; i++, RightEnd--)
		A[RightEnd] = TmpArray[RightEnd];
	for (i = 0; i < NumElements; i++, RightEnd++) {
		printf("%d ", A[RightEnd+1]);
	}
	printf("\n");
}

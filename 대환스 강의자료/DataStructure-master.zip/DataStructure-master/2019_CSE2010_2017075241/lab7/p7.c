#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>

#define min(x,y) (x<y?x:y)
#define max(x,y) (x>y?x:y)
 
int Find(int x, int *Disj_Sets); //i를 포함한 set의 root node를 반환하는 함수.
void Union(int *Disj_Sets, int r1, int r2); //서로 다른 두 root node를 연결하는 함수.
int *Init(int n); //모든 root node를 0으로 초기화 하는 함수
char **MakeTable(int row, int column); //미로 table을 만드는 함수.
void Print(char **table, int row, int column, FILE *fout); //미로를 출력하는 함수.
void Erase1(char **table, int x, int y, int n); //상하로 이웃한 두 node사이에 있는 엣지를 지우는 함수.
void Erase2(char **table, int x, int y, int n); //좌우로 이웃한 두 node사이에 있는 엣지를 지우는 함수.
int main() {
	srand((unsigned int)time(NULL));
	int n;
	int check = 0; //Union함수 실행 횟수를 저장.
	int *Disj_Sets = NULL;
	char **table = NULL;
	FILE *fin,*fout;
	fin = fopen("input.txt", "r");
	fout = fopen("output.txt", "w");
	fscanf(fin, "%d", &n);
	Disj_Sets = Init(n); 
	int row = n * 2 + 1;
	int column = n * 2 + 1;
	table = MakeTable(row, column);
	//모든 node가 union되면 while문 종료.
	while (check != n*n-1) {
		int x = rand() % (n*n) + 1;
		int y;
		int code = rand() % 2 + 1;
		switch (code)
		{
		case 1:
			y = x - n;
			if (y > 0) {
				if (Find(x, Disj_Sets) != Find(y, Disj_Sets)) {
					Union(Disj_Sets, Find(x, Disj_Sets), Find(y, Disj_Sets));
					check++;
					Erase1(table, x, y, n);
				}
			}
			break;
		case 2:
			y = x + 1;
			if (x % n != 0 && y <= n * n) {
				if (Find(x, Disj_Sets) != Find(y, Disj_Sets)) {
					Union(Disj_Sets, Find(x, Disj_Sets), Find(y, Disj_Sets));
					check++;
					Erase2(table, x, y, n);
				}
			}
			break;
		}
	}
	Print(table, row, column, fout);
	fclose(fin);
	fclose(fout);
	for (int i = 0; i < row; i++) 
		free(table[i]);
	free(table);
	free(Disj_Sets);
 
	return 0;
}
int Find(int x, int *Disj_Sets) {
	if (Disj_Sets[x] <= 0)
		return x;
	else
		return (Disj_Sets[x] = Find(Disj_Sets[x], Disj_Sets));
}
void Union(int *Disj_Sets, int r1, int r2) {
	if (Disj_Sets[r2] < Disj_Sets[r1])
		Disj_Sets[r1] = r2;
	else
	{
		if (Disj_Sets[r2] == Disj_Sets[r1])
			Disj_Sets[r1]--;
		Disj_Sets[r2] = r1;
	}
}
int *Init(int n) {
	int *Disj_Sets = (int*)malloc((n * n + 1) * sizeof(int));
	for (int i = 1; i < n * n + 1; i++)
		Disj_Sets[i] = 0;
	return Disj_Sets;
}
char **MakeTable(int row, int column) {
	char **table = (char**)malloc(row * sizeof(char*));
	for (int i = 0; i < row; i++)
		table[i] = (char*)malloc(column * sizeof(char));
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < column; j++) {
			if (i % 2 == 0) {
				if (j % 2 == 0)
					table[i][j] = '+';
				else
					table[i][j] = '-';
			}
			else {
				if (j % 2 == 0) {
					if ((i == 1 && j == 0) || (i ==row - 2 && j == column - 1))
						table[i][j] = ' ';
					else
						table[i][j] = '|';
				}
				else
					table[i][j] = ' ';
			}
		}
	}
	return table;
}
void Print(char **table, int row, int column, FILE *fout) {
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < column; j++) {
			fprintf(fout,"%c", table[i][j]);
		}
		fprintf(fout,"\n");
	}
}
void Erase1(char **table, int x, int y, int n) {
	if (x % n == 0)
		table[min(x, y) / n * 2][n * 2 - 1] = ' ';
	else
		table[max(x, y) / n * 2][y % n * 2 - 1] = ' ';
}
void Erase2(char **table, int x, int y, int n) {
	table[(min(x, y) / n + 1) * 2 - 1][(min(x, y) % n) * 2] = ' ';
}

#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct Node;
typedef struct Node *PtrToNode;
typedef PtrToNode Stack;
struct Node {
	char Operator;
	PtrToNode Next;
};
int IsEmpty(Stack S);
char Pop(Stack S, FILE *fout);
void Push(char X, Stack S, FILE *fout);
Stack CreateStack(FILE *fout);
char Top(Stack S, FILE *fout);
void MakeEmpty(Stack S, FILE *fout);

int main()
{
	int i = 0;
	int n = 0;
	int num;
	int operand1, operand2;
	char infix[100];
	char *postfix;
	char symbol;
	FILE *fin, *fout;
	fin = fopen("input3-3.txt", "r");
	fout = fopen("p3-3.out.txt", "w");
	if (fin == NULL)
		fprintf(fout, "Open Failed !!!\n");
	fgets(infix, sizeof(infix), fin);
	postfix = (char*)malloc(sizeof(char*)*strlen(infix));
	Stack S;
	S = CreateStack(fout);
	while(infix[n] != '#')
	{
		symbol = infix[n];
		switch (symbol)
		{
		case '(':
			Push(symbol,S,fout);
			break;
		case ')':
			while (1)
			{
				char Oper = Pop(S, fout);
				if (Oper == '(')
					break;
				postfix[i++] = Oper;
			}
			break;
		case '+':
		case '-':
			while (1)
			{
				char Oper = Pop(S, fout);
				if (Oper == '+' || Oper == '-' || Oper == '*' || Oper == '/' || Oper == '%')
				{
					postfix[i++] = Oper;
				}
				else
				{
					Push(Oper, S, fout);
					break;
				}
			}
			Push(symbol, S, fout);
			break;
		case '*':
		case '/':
		case '%':
			while (1)
			{
				char Oper = Pop(S, fout);
				if (Oper == '*' || Oper == '/' || Oper == '%')
				{
					postfix[i++] = Oper;
					
				}
				else
				{
					Push(Oper, S, fout);
					break;
				}
			}
			Push(symbol, S, fout);
			break;
		default:
			postfix[i++] = symbol;
			break;
		}
		n++;
	}
	while (IsEmpty(S) == 0)
		postfix[i++] = Pop(S, fout);
	infix[strlen(infix)-1] = '\0';
	postfix[i] = '\0';
	for (i = 0; i < strlen(postfix); i++)
	{
		symbol = postfix[i];
		if (symbol >= '1' && symbol <= '9')
		{
			num = symbol - 48;
			Push(num,S, fout);
		}
		else
		{
			operand2 = Pop(S,fout);
			operand1 = Pop(S,fout);

			switch (symbol)
			{
			case '+': Push(operand1 + operand2, S,fout); break;
			case '-': Push(operand1 - operand2, S,fout); break;
			case '*': Push(operand1 * operand2, S,fout); break;
			case '/': Push(operand1 / operand2, S,fout); break;
			case '%': Push(operand1 % operand2, S, fout); break;
			}		
		}
	}
	fprintf(fout, "Infix Form : %s\n", infix);
	fprintf(fout, "Postfix Form : %s\n", postfix);
	fprintf(fout, "Evaluation Result : %d", Pop(S, fout));
	fclose(fin);
	fclose(fout);
	free(postfix);
	MakeEmpty(S, fout);
	free(S);
	return 0;
}
//check stack S is empty or not
int IsEmpty(Stack S) {
	if (S->Next == NULL)
		return 1;
	else
		return 0;
}
//if stack S is not empty, return stack's next operator
char Pop(Stack S, FILE *fout) {
	PtrToNode FirstCell;
	if (IsEmpty(S))
		return 0;
	else {
		char top;
		top = Top(S, fout);
		FirstCell = S->Next;
		S->Next = S->Next->Next;
		free(FirstCell);
		return top;
	}
}
//put char X in stack S
void Push(char X, Stack S, FILE *fout) {
	PtrToNode TmpCell;
	TmpCell = malloc(sizeof(struct Node));
	if (TmpCell == NULL)
		fprintf(fout, "Out of space !!!\n");
	else {
		TmpCell->Operator = X;
		TmpCell->Next = S->Next;
		S->Next = TmpCell;
	}
}
//create stack S
Stack CreateStack(FILE *fout) {
	Stack S;
	S = malloc(sizeof(struct Node));
	if (S == NULL)
		fprintf(fout, "Out of space !!!\n");
	S->Next = NULL;
	return S;
}
//if stack S is not empty, return stack's next operator
char Top(Stack S, FILE *fout) {
	if (!IsEmpty(S))
		return S->Next->Operator;
	else {
		fprintf(fout, "Empty\n");
		return 0;
	}
}
//make stack S empty
void MakeEmpty(Stack S, FILE *fout) {
	if (S == NULL)
		fprintf(fout, "No stack exists");
	else
		while (!IsEmpty(S))
			Pop(S, fout);
}

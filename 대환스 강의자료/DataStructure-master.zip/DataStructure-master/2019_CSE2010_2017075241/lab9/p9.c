#include <stdio.h>
#include <stdlib.h>
 
#define order 3

struct B_node
{
	int n_keys; /*number of keys*/
	struct B_node *child[order];
	int key[order-1];
}*root=NULL;
enum KeyStatus { Success, InsertIt};// Key 상황에 따른 ENUM 형 자료형
enum KeyStatus ins(struct B_node *ptr, int key, int *upKey, struct B_node **newnode);// 삽입 처리(상태 파악)
void insert(int key);// 삽입 함수
int searchPos(int key, int *key_arr, int n);// 해당 노드에서 찾는 값의 위치 찾기
void inorder(struct B_node *ptr,FILE *fout);// 인오더형식으로 출력
void deleteTree(struct B_node *root);// 트리 동적할당 반환
int main()
{
	FILE *fin,*fout;
	fin = fopen("input.txt", "r");
	fout = fopen("output.txt", "w");
	while (!feof(fin))
	{
		int key;
		char code;
		fscanf(fin, "%c ", &code);
		switch (code)
		{
		case 'i':
			fscanf(fin, "%d ", &key);
			insert(key);
			break;
		case 'p':
			inorder(root,fout);
			break;
		}
	}

	deleteTree(root);

	fclose(fin);
	fclose(fout);

	return 0;
}
void insert(int key)
{
	struct node *newnode;
	int upKey;
	enum KeyStatus value;
	value = ins(root, key, &upKey, &newnode);
	if (value == InsertIt)
	{
		struct node *uproot = root;
		root = malloc(sizeof(struct B_node));
		root->n_keys = 1;
		root->key[0] = upKey;
		root->child[0] = uproot;
		root->child[1] = newnode;
	}
}
enum KeyStatus ins(struct B_node *ptr, int key, int *upKey, struct B_node **newnode)
{
	struct node *newPtr, *lastPtr;
	int pos, i, n, splitPos;
	int newKey, lastKey;
	enum KeyStatus value;
	if (ptr == NULL)
	{
		*newnode = NULL;
		*upKey = key;
		return InsertIt;
	}
	n = ptr->n_keys;
	pos = searchPos(key, ptr->key, n);
	value = ins(ptr->child[pos], key, &newKey, &newPtr);
	if (value != InsertIt)
		return value;
	if (n < order - 1)
	{
		pos = searchPos(newKey, ptr->key, n);
		for (i = n; i > pos; i--)
		{
			ptr->key[i] = ptr->key[i - 1];
			ptr->child[i + 1] = ptr->child[i];
		}
		ptr->key[pos] = newKey;
		ptr->child[pos + 1] = newPtr;
		++ptr->n_keys;
		return Success;
	}
	if (pos == order - 1)
	{
		lastKey = newKey;
		lastPtr = newPtr;
	}
	else 
	{
		lastKey = ptr->key[order - 2];
		lastPtr = ptr->child[order - 1];
		for (i = order - 2; i > pos; i--)
		{
			ptr->key[i] = ptr->key[i - 1];
			ptr->child[i + 1] = ptr->child[i];
		}
		ptr->key[pos] = newKey;
		ptr->child[pos + 1] = newPtr;
	}
	splitPos = (order - 1) / 2;
	(*upKey) = ptr->key[splitPos];
	(*newnode) = malloc(sizeof(struct B_node));
	ptr->n_keys = splitPos;
	(*newnode)->n_keys = order - 1 - splitPos;
	for (i = 0; i < (*newnode)->n_keys; i++)
	{
		(*newnode)->child[i] = ptr->child[i + splitPos + 1];
		if (i < (*newnode)->n_keys - 1)
			(*newnode)->key[i] = ptr->key[i + splitPos + 1];
		else
			(*newnode)->key[i] = lastKey;
	}
	(*newnode)->child[(*newnode)->n_keys] = lastPtr;
	return InsertIt;
}
int searchPos(int key, int *key_arr, int n)
{
	int pos = 0;
	while (pos < n && key > key_arr[pos])
		pos++;
	return pos;
}
void inorder(struct B_node *ptr,FILE* fout) {
	if (ptr) {
		if (ptr->n_keys >= 1) {
			inorder(ptr->child[0], fout);
			fprintf(fout,"%d ", ptr->key[0]);
			inorder(ptr->child[1], fout);
			if (ptr->n_keys == 2) {
				fprintf(fout,"%d ", ptr->key[1]);
				inorder(ptr->child[2], fout);
			}
		}
	}
}
void deleteTree(struct B_node *root) {
	if (root) {
		if (root->n_keys >= 1) {
			deleteTree(root->child[0]);
			deleteTree(root->child[1]);
			free(root);
			if (root->n_keys == 2) {
				deleteTree(root->child[2]);
				free(root);
			}
		}
	}
}


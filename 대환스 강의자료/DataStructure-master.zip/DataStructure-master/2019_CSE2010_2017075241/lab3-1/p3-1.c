#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct Node;
typedef struct Node *PtrToNode;
typedef PtrToNode Stack;
struct Node {
	int Number;
	PtrToNode Next;
};
int IsEmpty(Stack S);
void Pop(Stack S, FILE *fout);
void Push(int X, Stack S, FILE *fout);
Stack CreateStack(FILE *fout);
int Top(Stack S, FILE *fout);
void MakeEmpty(Stack S, FILE *fout);

int main()
{
	char code[10];
	FILE *fin, *fout;
	fin = fopen("input3-1.txt", "r"); 
	fout = fopen("p3-1.out.txt", "w");
	if (fin == NULL)
		fprintf(fout, "Open Failed !!!\n");
	Stack S;
	int num;
	S = CreateStack(fout);
	fscanf(fin, "%*d ");
	while (!feof(fin))
	{
		fscanf(fin, "%s ", code);
		if (strcmp(code, "push") == 0){
			fscanf(fin, "%d ", &num);
			Push(num, S, fout);
		}
		else if (strcmp(code, "pop") == 0){
			Pop(S, fout);
		}
	}
	fclose(fin);
	fclose(fout);
	MakeEmpty(S, fout);
	free(S);
	return 0;
}
//check stack S is empty or not
int IsEmpty(Stack S) {
	if (S->Next == NULL)
		return 1;
	else
		return 0;
}
//element stack's next number
void Pop(Stack S, FILE *fout){
	PtrToNode FirstCell;
	if (IsEmpty(S))
		fprintf(fout, "Empty\n");
	else {
		int top;
		top = Top(S, fout);
		fprintf(fout, "%d\n", top);
		FirstCell = S->Next;
		S->Next = S->Next->Next;
		free(FirstCell);
	}
}
//put int X in stack S
void Push(int X, Stack S, FILE *fout) {
	PtrToNode TmpCell;
	TmpCell = malloc(sizeof(struct Node));
	if (TmpCell == NULL)
		fprintf(fout, "Out of space !!!\n");
	else {
		TmpCell->Number = X;
		TmpCell->Next = S->Next;
		S->Next = TmpCell;
	}
}
//create Stack S
Stack CreateStack(FILE *fout) {
	Stack S;
	S = malloc(sizeof(struct Node));
	if (S == NULL)
		fprintf(fout, "Out of space !!!\n");
	S->Next = NULL;
	return S;
}
//if stack S is not empty, return stack's next number
int Top(Stack S, FILE *fout) {
	if (!IsEmpty(S))
		return S->Next->Number;
	else {
		fprintf(fout, "Empty\n");
		return 0;
	}
}
//make stack S empty
void MakeEmpty(Stack S,FILE *fout) {
	if (S == NULL)
		fprintf(fout,"No stack exists");
	else
		while (!IsEmpty(S))
			Pop(S,fout);
}

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
	char *name;
	int studentID;
	char *major;
}studentT;
int main()
{
	studentT *student;
	char len_name[30];
	char len_major[30];
	int n;
	FILE *fin, *fout;
	fin = fopen("student_information.txt", "r");
	fout = fopen("output2.txt", "w");
	fscanf(fin, "%d", &n);
	student = (studentT*)malloc(sizeof(studentT)*n);
	for (int i = 0; i < n; i++)
	{
		fscanf(fin, "%s %d %s", len_name, &student[i].studentID, len_major);
		student[i].name = (char*)malloc((strlen(len_name)) * sizeof(char));
		student[i].major = (char*)malloc((strlen(len_major)) * sizeof(char));
		student[i].name = len_name;
		student[i].major = len_major;
		printf("%s %d %s\n", student[i].name, student[i].studentID, student[i].major);
	}
	fclose(fin);
	
	for (int i = 0; i < n; i++)
	{
		printf("%s %d %s\n", student[i].name, student[i].studentID, student[i].major);
		fprintf(fout, "%s %d %s\n", student[i].name, student[i].studentID, student[i].major);
	}
	fclose(fout);
	free(student);

	return 0;
}

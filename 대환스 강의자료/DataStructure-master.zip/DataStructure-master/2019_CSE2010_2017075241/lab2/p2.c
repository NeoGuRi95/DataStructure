#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct
{
	char *studentID;
	char *studentName;
} ElementType;
typedef struct _node
{
	ElementType *element;
	struct _node *next;
}Node;
typedef struct {
	Node *head;
	Node *tail;
}LinkedList;

void MakeEmpty(LinkedList *L);
Node *FindePrevious(LinkedList *L, ElementType *X);
void Insert(LinkedList *L, ElementType *X, FILE *fout);
void Find(LinkedList *L, char *studentID, FILE *fout);
void PrintList(LinkedList *L, FILE *fout);
void Delete(LinkedList *L, ElementType *X, FILE *fout);

int main(void) 
{
	char code;
	LinkedList list;
	MakeEmpty(&list);
	ElementType *stu;
	FILE *fin, *fout;
	fin = fopen("input.txt", "r");
	fout = fopen("p2.out.txt", "w");
	while (!feof(fin))
	{
		stu = (ElementType*)malloc(sizeof(ElementType));
		stu->studentID = (char*)malloc(sizeof(char) * 30);
		stu->studentName = (char*)malloc(sizeof(char) * 30);
		fscanf(fin, "%c ", &code);
		if (code == 'i')
		{
			fscanf(fin, "%s %[^\n] ", stu->studentID, stu->studentName);
			Insert(&list,stu,fout);
		}
		else if (code == 'f')
		{
			fscanf(fin, "%s ", stu->studentID);
			Find(&list, stu->studentID, fout);
		}
		else if (code == 'd')
		{
			fscanf(fin, "%s ", stu->studentID);
			Delete(&list, stu, fout);
		}
		else if (code == 'p')
		{
			PrintList(&list, fout);
		}
	}
	fclose(fin);
	fclose(fout);
	free(stu->studentID);
	free(stu->studentName);
	free(stu);
	return 0;
}
void MakeEmpty(LinkedList *L) 
{
	L->head = NULL;
	L->tail = NULL;
}
Node *FindePrevious(LinkedList *L, ElementType *X)
{
	Node *temp = L->head;
	if (strcmp(L->head->element->studentID, X->studentID) == 0)
		return temp;
	while (temp->next != NULL && strcmp(temp->next->element->studentID, X->studentID) != 0)
		temp = temp->next;
	return temp;
}
void Insert(LinkedList *L, ElementType *X, FILE *fout) 
{
	Node *newNode = (Node *)malloc(sizeof(Node));
	newNode->element = X;
	newNode->next = NULL;
	if (L->head == NULL)
	{
		L->head = newNode;
		L->tail = newNode;
		fprintf(fout, "Insertion Success : %s\n", X->studentID);
		goto Print;
	}
	else
	{
		Node *temp = L->head;
		while (temp != NULL)
		{
			if (strcmp(temp->element->studentID, X->studentID) == 0)
			{
				fprintf(fout, "Insertion Failed. ID %s already exists.\n", X->studentID);
				free(newNode);
				return;
			}
			else if (strcmp(temp->element->studentID, X->studentID) > 0)
			{
				temp = FindePrevious(L, temp->element);
				if (temp == L->head)
				{
					newNode->next = temp;
					L->head = newNode;
					fprintf(fout, "Insertion Success : %s\n", X->studentID);
					goto Print;
				}
				else
				{
					newNode->next = temp->next;
					temp->next = newNode;
					fprintf(fout, "Insertion Success : %s\n", X->studentID);
					goto Print;
				}
			}
			temp = temp->next;
		}
		L->tail->next = newNode;
		L->tail = newNode;
		fprintf(fout, "Insertion Success : %s\n", X->studentID);
		goto Print;
	}
Print:
	{
		Node *temp = L->head;
		fprintf(fout, "Current List > ");
		while (temp != NULL)
		{
			fprintf(fout, "%s %s ", temp->element->studentID, temp->element->studentName);
			temp = temp->next;
		}
		fprintf(fout, "\n");
	}
}
void Find(LinkedList *L, char *studentID, FILE *fout)
{
	Node *temp = L->head;

	while (temp != NULL)
	{
		if (temp != NULL && strcmp(temp->element->studentID, studentID) != 0)
		{
			fprintf(fout, "Find %s Failed. There is no student ID\n", studentID);
			break;
		}
		else
		{
			fprintf(fout, "Find Success : %s %s\n", temp->element->studentID, temp->element->studentName);
			break;
		}
		temp = temp->next;
	}
}
void PrintList(LinkedList *L, FILE *fout)
{
	Node *temp = L->head;
	fprintf(fout, "-----LIST-----\n");
	while (temp != NULL)
	{
		fprintf(fout, "%s %s\n", temp->element->studentID, temp->element->studentName);
		temp = temp->next;
	}
	fprintf(fout, "--------------\n");
}
void Delete(LinkedList *L, ElementType *X, FILE *fout)
{
	Node *del = (Node*)malloc(sizeof(Node));
	del = FindePrevious(L, X);
	if (del->next == NULL)
	{
		fprintf(fout, "Deletion Failed : Student ID %s is not in the list.\n", X->studentID);
	}
	else
	{
		Node *tmpcell = (Node*)malloc(sizeof(Node));
		tmpcell = del->next;
		del->next = tmpcell->next;
		free(tmpcell);
		fprintf(fout, "Deletion Success : %s\n", X->studentID);
		Node *temp = L->head;
		fprintf(fout, "Current List > ");
		while (temp != NULL)
		{
			fprintf(fout, "%s %s ", temp->element->studentID, temp->element->studentName);
			temp = temp->next;
		}
		fprintf(fout, "\n");
	}
}

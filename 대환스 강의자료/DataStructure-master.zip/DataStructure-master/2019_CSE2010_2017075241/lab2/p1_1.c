#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#define swap(type, x, y) do{type t = x; x = y; y = t;} while(0)

void selection(int a[], int n)
{
	int i, j;
	for (i = 0; i < n - 1; i++) {
		int min = i;
		for (j = i + 1; j < n; j++)
			if (a[j] < a[min])
				min = j;
		swap(int, a[i], a[min]);
	}
}
int main()
{
	int k;
	int i;

	FILE *fp;
	fp = fopen("1_1test1.txt", "r");
	k = 0;
	fscanf(fp, "%d", &i);
	int *data = (int*)malloc(sizeof(int)*i);
	if (data == NULL)
	{
		printf("�޸� �Ҵ� ����");
	}
	for (k = 0; k < i; k++)
		fscanf(fp, "%d", &data[k]);
	selection(data, i);
	fclose(fp);
	fp = fopen("output.txt", "w");
	for (int n = 0; n < i; n++)
		fprintf(fp, "%d ", data[n]);
	fclose(fp);
	free(data);
	return 0;
}
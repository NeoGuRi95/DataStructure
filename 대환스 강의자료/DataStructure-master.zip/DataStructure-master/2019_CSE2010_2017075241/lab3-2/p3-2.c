#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX_QUEUE_SIZE 100
typedef struct {
	int key;
}element;
int rear = -1;
int front = 0;
void Enqueue(int X, element* queue, FILE *fout);
int Dequeue(element* queue, FILE *fout);

int main()
{
	char code[10];
	int num;
	element *queue;
	queue = (element*)malloc(sizeof(element)*MAX_QUEUE_SIZE);
	FILE *fin, *fout;
	fin = fopen("input3-2.txt", "r");
	fout = fopen("p3-2.out.txt", "w");
	fscanf(fin,"%*d ");
	while (!feof(fin))
	{
		fscanf(fin, "%s ", code);
		if (strcmp(code, "enQ") == 0)
		{
			fscanf(fin, "%d ", &num);
			Enqueue(num, queue,fout);
		}
		else if (strcmp(code, "deQ") == 0)
			Dequeue(queue,fout);
	}
	fclose(fin);
	fclose(fout);
	free(queue);
	return 0;
}
//put int X in queue
void Enqueue(int X, element* queue, FILE *fout)
{
	if (rear == MAX_QUEUE_SIZE - 1)
		fprintf(fout, "Full");
	queue[++rear].key = X;
}
//delete front queue's key
int Dequeue(element* queue, FILE *fout)
{
	if (front > rear)
		fprintf(fout, "Empty\n");
	else
	{
		fprintf(fout, "%d\n", queue[front].key);
	
	}
	front++;
}

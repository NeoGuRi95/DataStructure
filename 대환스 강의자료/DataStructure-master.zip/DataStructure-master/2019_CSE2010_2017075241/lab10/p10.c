#include <stdio.h>
#include <stdlib.h>
#include <string.h>
 
typedef struct _Graph {
	int size;
	int* node;
	int** matrix;
}Graph;
typedef struct _Queue {
	int* key;
	int first;
	int rear;
	int qsize;
	int max_queue_size;
}Queue;
 
Graph CreateGraph(int* node, int size); //그래프 생성
void InsertEdge(Graph G, int a, int b); //엣지삽입
void Topsort(Graph G,FILE* fout); //topological sort후 결과 출력
Queue MakeNewQueue(int X); //큐 생성
void Enqueue(Queue* Q, int X); //큐에 int X 추가
int Dequeue(Queue* Q); //처음 들어온 int X 제거
void Print(Graph G, FILE* fout); //인접행렬 출력
void Sort(Queue* Q); //값이 작은 순으로 큐 정렬
void DeleteGraph(Graph G); //그래프에서 할당된 인접행렬의 메모리 반환
int* CheckIndegree(Graph G, int* indegree); //각 vertext들의 indegree 확인
 
int main()
{
	FILE *fin,*fout;
	fin = fopen("input.txt", "r");
	fout = fopen("output.txt", "w");
	int* node;
	node = (int*)malloc(sizeof(int));
	char line[100];
	int key;
	int size = 0;
	fgets(line, 100, fin);
	char *ptr = strtok(line," ");
	while (ptr != NULL)
	{
		sscanf(ptr, "%d", &key);
		node[size++] = key;
		node = (int*)realloc(node, sizeof(int)*(size + 1));
		ptr = strtok(NULL, " ");
	}
	node = (int*)realloc(node, sizeof(int)*size);
	Graph G;
	G = CreateGraph(node, size);
	fgets(line, 100, fin);
	int a, b;
	char *ptr2 = strtok(line, "-");
	while (ptr2 != NULL)
	{
		sscanf(ptr2, "%d ", &a);
		ptr2 = strtok(NULL, " ");
		sscanf(ptr2, "%d ", &b);
		InsertEdge(G, a, b);
		ptr2 = strtok(NULL, "-");
	}
	Print(G,fout);
	Topsort(G,fout);
	DeleteGraph(G);
	fclose(fin);
	fclose(fout);
 
	return 0;
}
 
Graph CreateGraph(int* node, int size)
{
	Graph G;
	G.size = size;
	G.node = malloc(sizeof(int)*G.size);
	for (int i = 0; i < G.size; i++)
	{
		G.node[i] = node[i];
	}
	G.matrix = malloc(sizeof(int*)*G.size);
	for (int i = 0; i < G.size; i++)
	{
		G.matrix[i] = malloc(sizeof(int)*G.size);
	}
	for (int i = 0; i < G.size; i++)
	{
		for (int j = 0; j < G.size; j++)
		{
			G.matrix[i][j] = 0;
		}
	}
	return G;
}
void InsertEdge(Graph G, int a, int b)
{
	int i, j;
	for (int k = 0; k < G.size; k++)
	{
		if (G.node[k] == a)
			i = k;
		if (G.node[k] == b)
			j = k;
	}
	G.matrix[i][j] = 1;
}
void Topsort(Graph G, FILE* fout)
{
	Queue Q;
	Q = MakeNewQueue(G.size);
	int vertex;
	int* indegree;
	indegree = (int*)malloc(sizeof(int)*G.size);
	CheckIndegree(G, indegree);
	Queue result;
	result = MakeNewQueue(G.size);
	Queue sortQ;
	sortQ = MakeNewQueue(G.size);
	for (int i = 0; i < G.size; i++)
		if (indegree[i] == 0)
			Enqueue(&Q, G.node[i]);
	Sort(&Q);
	while (Q.qsize != 0)
	{
		vertex = Dequeue(&Q);
		Enqueue(&result, vertex);
		int i;
		for (i = 0; i < G.size; i++)
			if (G.node[i] == vertex)
				break;
		for (int j = 0; j < G.size; j++)
		{
			if (G.matrix[i][j] == 1)
				if (--indegree[j] == 0)
					Enqueue(&sortQ, G.node[j]);
		}
		Sort(&sortQ);
		while (sortQ.qsize != 0)
			Enqueue(&Q, Dequeue(&sortQ));
	}
	fprintf(fout,"\n\nTopSort Result : ");
	while (result.qsize != 0)
	{
		fprintf(fout,"%d ", Dequeue(&result));
	}
	fprintf(fout,"\n");
	free(Q.key);
	free(sortQ.key);
	free(result.key);
}
Queue MakeNewQueue(int X)
{
	Queue Q;
	Q.max_queue_size = X;
	Q.qsize = 0;
	Q.first = 0;
	Q.rear = 0;
	Q.key = malloc(sizeof(int)*X);
	return Q;
}
void Enqueue(Queue* Q, int X)
{
	if (Q->qsize == Q->max_queue_size)
		return;
	Q->key[Q->rear++] = X;
	Q->qsize++;
 
}
int Dequeue(Queue* Q)
{
	int key = Q->key[Q->first++];
	Q->qsize--;
	return key;
}
void Print(Graph G, FILE* fout)
{
	fprintf(fout,"Adjacency matrix\n  ");
	for (int i = 0; i < G.size; i++)
		fprintf(fout,"%d ", G.node[i]);
	fprintf(fout,"\n");
	for (int i = 0; i < G.size; i++)
	{
		fprintf(fout,"%d ", G.node[i]);
		for (int j = 0; j < G.size; j++)
		{
			fprintf(fout,"%d ", G.matrix[i][j]);
		}
		fprintf(fout,"\n");
	}
}
void Sort(Queue *Q)
{
	int temp;
	for (int i = Q->first; i < Q->rear; i++)    
	{
		for (int j = Q->first; j < Q->rear - 1; j++)
		{
			if (Q->key[j] > Q->key[j + 1])
			{                      
				temp = Q->key[j];
				Q->key[j] = Q->key[j + 1];
				Q->key[j + 1] = temp;
			}
		}
	}
}
void DeleteGraph(Graph G)
{
	free(G.node);
	for (int i = 0; i < G.size; i++)
		free(G.matrix[i]);
	free(G.matrix);
}
int* CheckIndegree(Graph G, int* indegree)
{
	for (int i = 0; i < G.size; i++)
		indegree[i] = 0;
	for (int j = 0; j < G.size; j++)
	{
		for (int i = 0; i < G.size; i++)
		{
			if (G.matrix[i][j] == 1)
				indegree[j]++;
		}
	}
	return indegree;
}

#include <stdio.h>
#include <stdlib.h>
 
typedef struct HeapStruct *PriorityQueue;
struct HeapStruct
{
	int Capacity;
	int Size;
	int *Elements;
};
 
void Insert(int X, PriorityQueue H, FILE* fout);//Max Heap에 X 삽입
void Find(int X, PriorityQueue H, FILE* fout);//Max Heap에서 X값이 있는지 확인.
void Print(PriorityQueue H, FILE* fout);//Max Heap을 인덱스순으로 값 출력.
int IsFull(PriorityQueue H);//Max Heap의 Capacity와 Size가 같은지 확인.
PriorityQueue InIt(int Capacity);//Max Heap 초기화.
 
int main()
{
	int Element;
	int Capacity;
	char code;
	FILE *fin, *fout;
	fin = fopen("input.txt", "r");
	fout = fopen("output.txt", "w");
	fscanf(fin, "%d ", &Capacity);
	PriorityQueue H = InIt(Capacity);
	while (!feof(fin))
	{
		fscanf(fin, "%c ", &code);
		switch (code)
		{
		case 'i':
			fscanf(fin, "%d ", &Element);
			Insert(Element, H, fout);
			break;
		case 'f':
			fscanf(fin, "%d", &Element);
			Find(Element, H, fout);
			break;
		case 'p':
			Print(H, fout);
			break;
		}
	}
	
	free(H->Elements);
	free(H);
 
	fclose(fin);
	fclose(fout);
 
	return 0;
}
 
void Insert(int X, PriorityQueue H, FILE* fout) 
{
	int i;
	if (IsFull(H))
	{
		fprintf(fout,"Priority queue is full\n");
		return;
	}
	else
	{
		for (i = 1; i <= H->Size; i++)
		{
			if (H->Elements[i] == X)
			{
				fprintf(fout, "%d is already in the heap.\n", X);
				return;
			}
		}
	}
	for (i = ++H->Size; i != 1 && H->Elements[i / 2] < X; i /= 2)
		H->Elements[i] = H->Elements[i / 2];
	fprintf(fout, "insert %d\n", X);
	H->Elements[i] = X;
}
void Find(int X, PriorityQueue H, FILE* fout)
{
	for (int i = 1; i <= H->Size; i++)
		if (H->Elements[i] == X)
		{
			fprintf(fout, "%d is in the heap.\n", X);
			return;
		}
	fprintf(fout, "%d is not in the heap.\n", X);
}
void Print(PriorityQueue H, FILE* fout)
{
	for (int i = 1; i <= H->Size; i++)
		fprintf(fout, "%d ", H->Elements[i]);
	fprintf(fout, "\n");
}
int IsFull(PriorityQueue H)
{
	if (H->Capacity == H->Size)
		return 1;
	else
		return 0;
}
PriorityQueue InIt(int Capacity)
{
	PriorityQueue H = malloc(sizeof(struct HeapStruct));
	H->Capacity = Capacity;
	H->Size = 0;
	H->Elements = malloc(sizeof(int)*Capacity);
	return H;
}

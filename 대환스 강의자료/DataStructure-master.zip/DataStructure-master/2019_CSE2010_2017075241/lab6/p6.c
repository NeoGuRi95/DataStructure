#include <stdio.h>
#include <stdlib.h>

struct AVLNode;
typedef struct AVLNode *Position;
typedef struct AVLNode *AVLTree;
typedef struct AVLNode
{
	int value;
	AVLTree Left;
	AVLTree Right;
	int Height;
}AVLNode;
int NumOfNodes = 0; // 트리의 노드 개수를 계산하기 위해 사용.
int Max(int a, int b); //두 정수값 중 더 큰 값을 반환하는 함수. 
int Height(Position P);//노드 P의 height를 반환하는 함수.
AVLTree Insert(int X, AVLTree T,FILE *fout); //트리에 새 노드를 추가하는 함수.
Position SingleRotateWithLeft(Position K2); //새 노드가 K2의 left의 left에 추가되면서 트리의 밸런스가 깨졌을 때 K2와 K2의 left를 rotation하여 밸런스를 맞추는 함수.
Position SingleRotateWithRight(Position K2); //새 노드가 K2의 right의 right에 추가되면서 트리의 밸런스가 깨졌을 때 K2와 K2의 right를 rotation하여 밸런스를 맞추는 함수.
Position DoubleRotateWithLeft(Position K3); //새노드가 K3의 left의 right에 추가되면서 트리의 밸런스가 깨졌을 때 SingleRotateWithRight(K3->Left),SingleRotateWithLeft(K3)를 실행하여 밸런스를 맞추는 함수.
Position DoubleRotateWithRight(Position K3); //새노드가 K3의 right의 left에 추가되면서 트리의 밸런스가 깨졌을 때 SingleRotateWithLeft(K3->Right),SingleRotateWithRight(K3)를 실행하여 밸런스를 맞추는 함수.
void PrintInorder(AVLTree T, FILE *fout); //트리의 value값을 인오더 방식으로 출력하는 함수.
void MakeEmptyTree(AVLTree T); //할당된 트리의 모든 노드의 메모리를 반환하는 함수.
int main()
{
	AVLTree T= NULL;
	int cmpNum;
	int value;
	FILE *fin,*fout;
	fin = fopen("input.txt", "r");
	fout = fopen("output.txt", "w");
	while (!feof(fin)) {
		fscanf(fin,"%d ", &value);
		cmpNum = NumOfNodes;
		T = Insert(value, T,fout);
		if (cmpNum != NumOfNodes) {
			PrintInorder(T, fout);
			fprintf(fout, "\n");
		}
	}
	MakeEmptyTree(T);
	fclose(fin);
	fclose(fout);
	return 0;
}
int Max(int a,int b) {
	return a>b? a : b;
}
int Height(Position P) {
	if (P == NULL)
		return -1;
	else
		return P->Height;
}
Position SingleRotateWithLeft(Position K2) {
	Position K1;
	K1 = K2->Left;
	K2->Left = K1->Right;
	K1->Right = K2;
	K2->Height = Max(Height(K2->Left), Height(K2->Right)) + 1;
	K1->Height = Max(Height(K1->Left), K2->Height) + 1;
	return K1;
}
Position SingleRotateWithRight(Position K2) {
	Position K1;
	K1 = K2->Right;
	K2->Right = K1->Left;
	K1->Left = K2;
	K2->Height = Max(Height(K2->Left), Height(K2->Right)) + 1;
	K1->Height = Max(Height(K1->Left), K2->Height) + 1;
	return K1;
}
Position DoubleRotateWithLeft(Position K3) {
	K3->Left = SingleRotateWithRight(K3->Left);
	return SingleRotateWithLeft(K3);
}
Position DoubleRotateWithRight(Position K3) {
	K3->Right = SingleRotateWithRight(K3->Right);
	return SingleRotateWithRight(K3);
}
AVLTree Insert(int X, AVLTree T,FILE *fout) {
	if (T == NULL) {
		T = malloc(sizeof(struct AVLNode));
		if (T == NULL)
			printf("Out of space!!!\n");
		else {
			T->value = X; T->Height = 0;
			T->Left = T->Right = NULL;
			NumOfNodes++; //트리의 노드개수 증가.
		}
	}
	else if (X < T->value) {
		T->Left = Insert(X, T->Left,fout);
		if (Height(T->Left) - Height(T->Right) == 2)
			if (X < T->Left->value)
				T = SingleRotateWithLeft(T);
			else
				T = DoubleRotateWithLeft(T);
	}
	else if (X > T->value) {
		T->Right = Insert(X, T->Right, fout);
		if (Height(T->Right) - Height(T->Left) == 2)
			if (X > T->Right->value)
				T = SingleRotateWithRight(T);
			else
				T = DoubleRotateWithRight(T);
	}
	else
		fprintf(fout, "%d already in the tree!\n", X);
	T->Height = Max(Height(T->Left), Height(T->Right)) + 1;
 
	return T;
}
void PrintInorder(AVLTree T, FILE *fout) {
	if (T) {
		PrintInorder(T->Left, fout);
		fprintf(fout, "%d(%d) ", T->value,T->Height);
		PrintInorder(T->Right, fout);
	}
}
void MakeEmptyTree(AVLTree T) {
	if (T) {
		MakeEmptyTree(T->Left);
		MakeEmptyTree(T->Right);
		free(T);
	}
}
